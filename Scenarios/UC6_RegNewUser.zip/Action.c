Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	lr_start_transaction("UC6_RegNewUser");
	
	lr_start_transaction("open_home_page");
	
	web_reg_find("Text/IC=Welcome to the Web Tours site",LAST);
	
		web_add_auto_header("DNT", "1");
		web_add_auto_header("Sec-Fetch-Dest", "frame");
		web_add_auto_header("Sec-Fetch-Mode", "navigate");
		web_add_auto_header("Sec-Fetch-Site", "same-origin");
		web_add_auto_header("Upgrade-Insecure-Requests", "1");
		web_add_auto_header("sec-ch-ua", "\"Chromium\";v=\"112\", \"Google Chrome\";v=\"112\", \"Not:A-Brand\";v=\"99\"");
		web_add_auto_header("sec-ch-ua-mobile", "?0");
		web_add_auto_header("sec-ch-ua-platform", "\"Windows\"");
		web_url("welcome.pl", 
			"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
			"TargetFrame=", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/WebTours/", 
			"Snapshot=t1.inf", 
			"Mode=HTML", LAST);

	lr_end_transaction("open_home_page", LR_AUTO);
	
	lr_think_time(5);
	
	lr_start_transaction("click_sign_up_now");
	
	web_reg_find("Text/IC=Please choose a username and password combination for your account.",
		LAST);
	
		web_add_auto_header("Sec-Fetch-User", "?1");
		web_url("login.pl", 
			"URL=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/WebTours/home.html", 
			"Snapshot=t2.inf", 
			"Mode=HTML", LAST);
	
	lr_end_transaction("click_sign_up_now", LR_AUTO);
	
	lr_think_time(5);
	
	lr_start_transaction("customer_profile");
	
	web_reg_find("Text/IC=Thank you, <b>{login}{random}</b>, for registering and welcome to the Web Tours family.",
		LAST);

		web_add_header("Origin", "http://localhost:1080");
		web_submit_data("login.pl_2", 
			"Action=http://localhost:1080/cgi-bin/login.pl", 
			"Method=POST", 
			"TargetFrame=info", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
			"Snapshot=t3.inf", 
			"Mode=HTML", ITEMDATA, 
			"Name=username", "Value={login}{random}", ENDITEM, 
			"Name=password", "Value={password}{random}", ENDITEM, 
			"Name=passwordConfirm", "Value={password}{random}", ENDITEM, 
			"Name=firstName", "Value={firstName}{random}", ENDITEM, 
			"Name=lastName", "Value={lastName}{random}", ENDITEM, 
			"Name=address1", "Value={address1}{random}", ENDITEM, 
			"Name=address2", "Value={address2}{random}", ENDITEM, 
			"Name=register.x", "Value=50", ENDITEM, 
			"Name=register.y", "Value=6", ENDITEM, LAST);
	
	lr_end_transaction("customer_profile", LR_AUTO);
	
	lr_think_time(5);
	
	lr_start_transaction("click_cont_to_end_of_registration");
	
	web_reg_find("Text/IC=Welcome, <b>{login}{random}</b>, to the Web Tours reservation pages",LAST);

		web_revert_auto_header("Sec-Fetch-User");
		web_revert_auto_header("Upgrade-Insecure-Requests");
		web_add_header("Sec-Fetch-User", "?1");
		web_url("button_next.gif", 
			"URL=http://localhost:1080/cgi-bin/welcome.pl?page=menus", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/login.pl", 
			"Snapshot=t4.inf", 
			"Mode=HTML", LAST);
	
	lr_end_transaction("click_cont_to_end_of_registration", LR_AUTO);
	
	lr_think_time(5);
	
	lr_start_transaction("signoff");
	
	web_reg_find("Text/IC=Welcome to the Web Tours site.",LAST);

		web_add_header("Upgrade-Insecure-Requests", "1");
		web_url("SignOff Button", 
			"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
			"Snapshot=t5.inf", 
			"Mode=HTML", LAST);
	
	lr_end_transaction("signoff", LR_AUTO);

	lr_end_transaction("UC6_RegNewUser", LR_AUTO);

	return 0;
}